
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def home(request):
    return render(request, 'home.html', {})

def telalogin(request):
    return render(request, 'login.html')


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('', index, name='index'),
    path('game/', include('game.urls')),
    path('telalogin/', telalogin, name='telalogin')
]
