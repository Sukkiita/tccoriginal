from django.shortcuts import render, redirect
from .forms import GameForm
from django.db.models import Q
from .models import Game

def cadastrar(request):
    if request.method == 'POST':
        form = GameForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('rel_game')
    else:
        form = GameForm()
    return render(request, 'gamecadastrar.html', {'form': form})

def rel_game(request):
    return render(request, "acesso.html")

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        senha = request.POST['senha']
        try:
            game = Game.objects.get(Q(email=email) & Q(senha=senha))
            return redirect('administrador')
        except Game.DoesNotExist:
            erro = 'Email ou senha inválidos.'
            return render(request, 'login.html', {'error_message': erro})

def administrador(request):
    return render(request, 'admin.html')
